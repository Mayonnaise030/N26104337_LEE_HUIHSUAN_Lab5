import pygame
import os
MENU_IMAGE = pygame.image.load(os.path.join("images", "upgrade_menu.png"))
UPGRADE_IMAGE = pygame.image.load(os.path.join("images", "upgrade.png"))
SELL_IMAGE = pygame.image.load(os.path.join("images", "sell.png"))
font = pygame.font.SysFont("Terminal", 30)
class UpgradeMenu:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        # initial the image
        self.menu_image = pygame.transform.scale(MENU_IMAGE, (200, self.200)) 
        self.upgrade_image = pygame.transform.scale(UPGRADE_IMAGE, (50, 50))
        self.sell_image = pygame.transform.scale(SELL_IMAGE, (50, 50))
        # get the rec information of image
        self.menu_rect = self.menu_image.get_rect()
        self.upgrade_rect = self.upgrade_image.get_rect()
        self.sell_rect = self.sell_image.get_rect()
        # set the center of image
        self.menu_rect.center = (x, y)
        self.upgrade_rect.center = (x, y-50)  # upgrade button place
        self.sell_rect.center = (x, y+50)     # sell button place
        # set the buttons of upgrade and sell
        self.__buttons = [Button(self.upgrade_image,"upgrade",self.x, self.upgrade_rect.center[1]),
                          Button(self.sell_image,"sell",self.x, self.sell_rect.center[1])]  # (Q2) Add buttons here
        pass

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.menu_image, self.menu_rect)          #build menu 
        # draw button
        win.blit(self.upgrade_image, self.upgrade_rect)    #build upgrade button image
        win.blit(self.sell_image, self.sell_rect)          #build sell button image
        # (Q2) Draw buttons here
        pass

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        return self.__buttons  #return the button you own
        pass


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.image = pygame.transform.scale(image, (100, 100))  #just set the range you can click of image
        self.rect = self.image.get_rect()                       # get the rec information of image
        self.rect.center = (x, y)                               # center of the Button
    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False  #determine in the range or not
        pass

    def response(self):
        return self.name                                        #return the name of button to response
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        pass






